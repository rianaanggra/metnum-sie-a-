#include <stdio.h>
#include <conio.h>
#include <windows.h>
#include <math.h>
#define nmax 100

int main  (){
	
int angka, jarak;
int x[nmax+1];
int y[nmax+1];
float prediksi[nmax+1], error[nmax+1];
float m, c, fx, er;
int n, i;
int sig_x, sig_er, sig_xy=0, sig_x2=0, sig_y2=0;
int sig_y;
int x2[nmax+1], y2[nmax+1], xy[nmax+1];

printf("\n                          MENGHITUNG REGRESI LINIER\n");
printf("--------------------------------------------------------------------------------");
printf("\n   3411151055 - Riana Anggra Kusumah || 3411151084 - Restu Fatimah Indah Sari   ");
printf("--------------------------------------------------------------------------------\n");
printf ("\n                                Banyak Data : "); scanf ("%d", &n);
system("cls");

for(i=1;i<=n;i++){
	printf("\n                           MASUKKAN NILAI X[%d] : ",i);scanf("%d", &angka);
	x[i]=angka;
	x2[i]=pow(x[i], 2);
    sig_x=sig_x + x[i];
    sig_x2=sig_x2 + x2[i];
} 

for(i=1;i<=n;i++){
	printf("\n                           MASUKKAN NILAI Y[%d] : ",i);
	scanf("%d", &angka);
	y[i]=angka;
	y2[i]=pow(y[i], 2);
    sig_y= sig_y + y[i];
    sig_y2=sig_y2 + y2[i];
    xy[i]=x[i]*y[i];
    sig_xy=sig_xy + xy[i];
} 

system("cls");

printf ("\n                                 REGRESI DATA   \n");
	printf("\n            |======================================================|");
	printf("\n            |    X    |    Y    |    X.X    |    Y.Y    |    XY    |");
	printf("\n            |======================================================|");
for (i=1; i<=n;i++){
	printf("\n                 %d         %d          %d           %d           %d\n", x[i], y[i], x2[i], y2[i], xy[i]);
}   printf("\n            |======================================================|");
	printf("\n 	         %d      %d       %d           %d           %d\n", sig_x, sig_y, sig_x2, sig_y2, sig_xy);

  printf("\n               MENGHITUNG m DAN c UNTUK RUMUS PERSAMAAN LINIER\n");

  m=((angka*sig_xy)-(sig_x*sig_y)) / ((angka*sig_x2)-pow(sig_x, 2));
  printf("\n                            NILAI m = %f \n", m);
  
  c=((sig_y*sig_x2)-(sig_x*sig_xy)) / ((angka*sig_x2)-pow(sig_x, 2));
  printf("\n                            NILAI c = %f \n", c);
  
  printf ("\n                            MASUKKAN JARAK : "); scanf("%d", &jarak);
  fx=(m*jarak)+c;
  printf("\n                         Hasil jarak f(x) = %f \n", fx);
  
  for (i=1; i<=n;i++){
      prediksi[i]=(m*x[i])+c;
      printf ("\n                   Nilai Prediksi Jarak jika f[%d] = %f \n", x[i], prediksi[i]);
  }
  
   for (i=1; i<=n;i++){
   	error[i]=y[i]-prediksi[i];
   	sig_er=sig_er + error[i];
   	er=sig_er/n;
   }
   
   for (i=1; i<=n;i++){
    	printf ("\n                  Nilai Prediksi Waktu jika f(x)=%f yaitu %f \n", prediksi[i], error[i]);
}
   printf("\n--------------------------------------------------------------------------------");
   printf("\n    Maka Jarak f(x)= %f memiliki nilai error sebesar %f \n ", fx, er);
   
  return 0;
}
